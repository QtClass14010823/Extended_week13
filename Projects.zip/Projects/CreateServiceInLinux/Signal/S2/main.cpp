#include <signal.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

// Compliant Solution
void term_handler(int signum) {
    /* SIGTERM handler */
    cout << "Signal received." << endl;
}

void int_handler(int signum) {
    /* SIGINT handler */
    /* Pass control to the SIGTERM handler */
    term_handler(SIGTERM);
}

int main(void)
{
    if (signal(SIGTERM, term_handler) == SIG_ERR) {
        /* Handle error */
    }
    if (signal(SIGINT, int_handler) == SIG_ERR) {
        /* Handle error */
    }

    /* Program code */
    if (raise(SIGINT) != 0) {
        /* Handle error */
    }
    /* More code */

    cout << "Exiting..." << endl;

    return EXIT_SUCCESS;
}

// Noncompliant Code
//void term_handler(int signum) {
//    /* SIGTERM handler */
//    cout << "Signal received." << endl;
//}

//void int_handler(int signum) {
//    /* SIGINT handler */
//    if (raise(SIGTERM) != 0) {
//        /* Handle error */
//    }
//}

//int main(void)
//{
//    if (signal(SIGTERM, term_handler) == SIG_ERR) {
//        /* Handle error */
//    }
//    if (signal(SIGINT, int_handler) == SIG_ERR) {
//        /* Handle error */
//    }

//    /* Program code */
//    if (raise(SIGINT) != 0) {
//        /* Handle error */
//    }
//    /* More code */

//    cout << "Exiting..." << endl;

//    return EXIT_SUCCESS;
//}
