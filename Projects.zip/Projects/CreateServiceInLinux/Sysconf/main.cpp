#include <stdio.h>
#include <unistd.h>
#include <errno.h>

// The maximum number of files that a single process can have open at one time.
int main()
{
    long int result;

    errno = 0;
    puts("examining OPEN_MAX limit");
    if ((result = sysconf(_SC_OPEN_MAX)) == -1)
        if (errno == 0)
            puts("OPEN_MAX is not supported.");
        else perror("sysconf() error");
    else
        printf("OPEN_MAX is %ld\n", result);

    return 0;
}
