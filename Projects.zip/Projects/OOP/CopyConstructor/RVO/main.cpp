#include <iostream>

using namespace std;

class BigObject {
public:
    BigObject() {
        cout << "constructor. " << endl;
    }
    ~BigObject() {
        cout << "destructor."<< endl;
    }
    BigObject(const BigObject&) {
        cout << "copy constructor." << endl;
    }
};

BigObject foo() {
    BigObject localObj;
    return localObj;
}

int main() {
    BigObject obj = foo();
    // output is like this:
    // constructor.
    // destructor.
}

