// C++ program to demonstrate accessing of data members
#include <iostream>

using namespace std;

class MyClass {
    // Access specifier
public:
    // Data Members
    string classname;
    // Member Functions()
    void printname() { cout << "Class name is:" << classname<<endl; }
};

int main()
{
    // Declare an object of class MyClass
    MyClass obj1;
    // accessing data member
    obj1.classname = "MyClass";
    // accessing member function
    obj1.printname();
    return 0;
}
