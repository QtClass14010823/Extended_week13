﻿#include "Form.h"

#include <QGridLayout>
#include <QPushButton>
#include <QMessageBox>

Form::Form(const QStringList &texts, QWidget *parent)
    : QWidget(parent)
{
    QGridLayout *gridLayout = new QGridLayout(this);

    for (int i = 0; i < texts.size(); ++i)
    {
        QPushButton *button = new QPushButton(texts[i]);
        connect(button, &QPushButton::clicked, this, &Form::clicked);
        gridLayout->addWidget(button, i / 3, i % 3);
    }
}

void Form::clicked(bool checked/* = false*/)
{
    QMessageBox::information(this, "information", qobject_cast<QPushButton *>(sender())->text());
}
