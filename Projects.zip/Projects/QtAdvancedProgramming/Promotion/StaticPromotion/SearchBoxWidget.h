﻿#ifndef SEARCHBOXWIDGET_H
#define SEARCHBOXWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QLineEdit>
#include <QPushButton>

class SearchBoxWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SearchBoxWidget(QWidget *parent = nullptr);

signals:
    void onSearch(const QString text);

private slots:
    void on_lnEditSearch_textChanged(const QString &text);
    void on_btnSearch_Clicked(bool checked = false);

private:
    QHBoxLayout *hlay;
    QLineEdit *lnEditSearch;
    QPushButton *btnSearch;
};

#endif // SEARCHBOXWIDGET_H
