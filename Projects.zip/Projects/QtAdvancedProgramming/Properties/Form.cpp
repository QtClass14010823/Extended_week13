﻿#include "Form.h"

#include <QPushButton>
#include <QRadioButton>
#include <QVariant>
#include <QMessageBox>

Form::Form(QWidget *parent) : QWidget(parent), lastChecked(nullptr)
{
    vlay = new QVBoxLayout(this);
    hlay = new QHBoxLayout;

    QPushButton *btn;
    QRadioButton *rdoBtn;

    rdoBtn = new QRadioButton("Circle");
    rdoBtn->setProperty("Id", 1);
    rdoBtn->setProperty("Sides", 0);
    rdoBtn->setProperty("Color", "Red");
    connect(rdoBtn, &QRadioButton::toggled, this, &Form::on_RadioBtn_Toggled);
    hlay->addWidget(rdoBtn);

    rdoBtn = new QRadioButton("Square");
    rdoBtn->setProperty("Id", 2);
    rdoBtn->setProperty("Sides", 4);
    rdoBtn->setProperty("Color", "Blue");
    connect(rdoBtn, &QRadioButton::toggled, this, &Form::on_RadioBtn_Toggled);
    hlay->addWidget(rdoBtn);

    rdoBtn = new QRadioButton("Triangle");
    rdoBtn->setProperty("Id", 3);
    rdoBtn->setProperty("Sides", 3);
    rdoBtn->setProperty("Color", "Green");
    connect(rdoBtn, &QRadioButton::toggled, this, &Form::on_RadioBtn_Toggled);
    hlay->addWidget(rdoBtn);

    rdoBtn = new QRadioButton("Rectangle");
    rdoBtn->setProperty("Id", 4);
    rdoBtn->setProperty("Sides", 4);
    rdoBtn->setProperty("Color", "Yellow");
    connect(rdoBtn, &QRadioButton::toggled, this, &Form::on_RadioBtn_Toggled);
    hlay->addWidget(rdoBtn);

    btn = new QPushButton("Select");

    vlay->addLayout(hlay);
    vlay->addWidget(btn);

    connect(btn, &QPushButton::clicked, this, &Form::on_PushBtn_Clicked);
}

void Form::on_RadioBtn_Toggled(bool checked)
{
    lastChecked = sender();
}

void Form::on_PushBtn_Clicked(bool checked/* = false*/)
{
    QRadioButton *rdoBtn;

    if ((rdoBtn = qobject_cast<QRadioButton *>(lastChecked)))
    {
        QMessageBox::information(this, "Information", QString("Id: %0\nSides: %1\nColor: %2")
                                 .arg(rdoBtn->property("Id").toInt())
                                 .arg(rdoBtn->property("Sides").toInt())
                                 .arg(rdoBtn->property("Color").toString()));
    }
    else
    {
        QMessageBox::critical(this, "Error", "No item selected.");
    }
}
