﻿#include "TcpServer.h"

#include "TcpServer.h"
#include "SocketThread.h"

#include <QRandomGenerator>

#include <stdlib.h>

TcpServer::TcpServer(QObject *parent)
    : QTcpServer(parent)
{
    texts << tr("Sample text 1.")
             << tr("Sample text 2.")
             << tr("Sample text 3.")
             << tr("Sample text 4.")
             << tr("Sample text 5.")
             << tr("Sample text 6.")
             << tr("Sample text 7.");
}

void TcpServer::incomingConnection(qintptr socketDescriptor)
{
    QString text = texts.at(QRandomGenerator::global()->bounded(texts.size()));
    SocketThread *thread = new SocketThread(socketDescriptor, text, this);
    connect(thread, &SocketThread::finished, thread, &SocketThread::deleteLater);
    thread->start();
}
