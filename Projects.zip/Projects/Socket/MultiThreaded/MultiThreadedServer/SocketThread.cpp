﻿#include "SocketThread.h"

#include <QtNetwork>

SocketThread::SocketThread(qintptr socketDescriptor, const QString &text, QObject *parent)
    : QThread(parent), socketDescriptor(socketDescriptor), text(text)
{
}

void SocketThread::run()
{
    QTcpSocket tcpSocket;

    if (!tcpSocket.setSocketDescriptor(socketDescriptor)) {
        emit error(tcpSocket.error());
        return;
    }

    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_15);
    out << text;

    tcpSocket.write(block);
    tcpSocket.disconnectFromHost();
    tcpSocket.waitForDisconnected();
}
