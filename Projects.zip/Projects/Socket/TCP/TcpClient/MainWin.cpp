﻿#include "MainWin.h"

#include <QGridLayout>
#include <QHostAddress>

MainWin::MainWin(QWidget *parent) : QWidget(parent)
{
    init();
}

void MainWin::onConnectToHost()
{
    btnSend->setEnabled(true);
    prgsWait->hide();
}

void MainWin::onBtnConnectClicked()
{
    QHostAddress host("127.0.0.1");
    socket->connectToHost(host, 2000);
    prgsWait->show();
}

void MainWin::onBtnSendClicked()
{
    QByteArray data = lnEditText->text().toLatin1();
    socket->write(data);
}

void MainWin::init()
{
    lblText = new QLabel("Text:");
    lnEditText = new QLineEdit;
    btnConnect = new QPushButton("Connect");
    btnSend = new QPushButton("Send");
    prgsWait = new QProgressBar;
    prgsWait->setMinimum(0);
    prgsWait->setMaximum(0);
    prgsWait->setTextVisible(false);
    btnSend->setDisabled(true);
    prgsWait->hide();

    QGridLayout *grdLay = new QGridLayout;
    grdLay->addWidget(lblText, 0, 0);
    grdLay->addWidget(lnEditText, 0, 1);
    grdLay->addWidget(btnConnect, 0, 2);
    grdLay->addWidget(btnSend, 0, 3);
    grdLay->addWidget(prgsWait, 1, 1, 1, 3);
    this->setLayout(grdLay);

    socket = new QTcpSocket(this);

    connect(socket, &QTcpSocket::connected, this, &MainWin::onConnectToHost);
    connect(btnConnect, &QPushButton::clicked, this, &MainWin::onBtnConnectClicked);
    connect(btnSend, &QPushButton::clicked, this, &MainWin::onBtnSendClicked);
}
