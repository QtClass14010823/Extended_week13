#include <iostream>
using namespace std;

int main()
{
    const string str
        = "Welcome\nTo\nGeeks\tFor\tGeeks";
    cout << str;
    return 0;
}
