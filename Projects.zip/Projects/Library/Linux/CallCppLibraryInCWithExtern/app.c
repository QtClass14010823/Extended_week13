#include<stdio.h>
#include<dlfcn.h>

typedef int (add_func) (int a, int b);
void *lib_handle = NULL;
add_func * add;

int main (int argc, char *argv[])
{
    int a = 1, b = 2, c;
    lib_handle = (void *)dlopen("./libmathlib.so", RTLD_LAZY);
    if(lib_handle)
    {
        printf("dlopen returns %p\n", lib_handle);
        add = dlsym(lib_handle, "add");
        if(add)
        {
            printf("dlsym returns add = %p\n", add);
            c = add (a, b);
            printf("%d + %d = %d\n", a, b, c);
        }
        else
        {
            printf("Function entry not found in library.");
        }
        dlclose(lib_handle);
    }
    else
    {
        printf("Unable to open library.");
    }
}
