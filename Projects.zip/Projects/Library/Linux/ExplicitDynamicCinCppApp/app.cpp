#include <iostream>
#include <dlfcn.h>

using namespace std;

typedef int (add_func) (int a, int b);
void *lib_handle = NULL;
add_func * add;

int main (int argc, char *argv[])
{
    int a = 1, b = 2, c;
    lib_handle = (void *)dlopen("./libmathlib.so", RTLD_LAZY);
    if(lib_handle)
    {
        cout << "dlopen returns " << lib_handle << endl;
        add = (add_func *)dlsym(lib_handle, "add");
        if(add)
        {
            cout << "dlsym returns add = " << add << endl;
            c = add (a, b);
            cout << a << " + " << b << " = " << c << endl;
        }
        else
        {
            cout << "Function entry not found in library.";
        }
        dlclose(lib_handle);
    }
    else
    {
        cout << "Unable to open library.";
    }
}
