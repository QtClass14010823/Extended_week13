#include <stdio.h>
#include "mathlib.h"

int main (int argc, char *argv[])
{
    int result;
    result = add(1, 2);
    printf ("1 + 2 = %d\n", result);
    result = subtract(3, 2);
    printf ("3 - 2 = %d\n", result);
    result = multiply(3, 2);
    printf ("3 * 2 = %d\n", result);
    result = divition(4, 2);
    printf ("4 / 2 = %d\n", result);
    return 0;
}
