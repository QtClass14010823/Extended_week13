#define DLL_FUNCTION __declspec(dllexport)

#include "mathlib.h"

DLL_FUNCTION int add(int a, int b)
{
    return (a + b);
}

DLL_FUNCTION int subtract(int a, int b)
{
    return (a - b);
}

DLL_FUNCTION int multiply(int a, int b)
{
    return (a * b);
}

DLL_FUNCTION int divition(int a, int b)
{
    return (a / b);
}
