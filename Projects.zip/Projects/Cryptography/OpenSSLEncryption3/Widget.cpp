﻿#include "Widget.h"

#include <QGridLayout>
#include <QMessageBox>
#include <openssl/aes.h>

Widget::Widget(QWidget *parent) : QWidget(parent),
    key {
      0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
      0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
      0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
      0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    }
{
    lblPlain = new QLabel("Plain Text:");
    lnEditPlain = new QLineEdit;
    lblEncrypted = new QLabel("Encrypted Text:");
    lnEditEncrypted = new QLineEdit;
    lblDecrypted = new QLabel("Decrypted Text:");
    lnEditDecrypted = new QLineEdit;
    pshBtnEncrypt = new QPushButton("Encrypt");
    pshBtnDecrypt = new QPushButton("Decrypt");;
    QGridLayout *gLay = new QGridLayout;

    gLay->addWidget(lblPlain, 0, 0);
    gLay->addWidget(lnEditPlain, 0, 1);
    gLay->addWidget(lblEncrypted, 1, 0);
    gLay->addWidget(lnEditEncrypted, 1, 1);
    gLay->addWidget(pshBtnEncrypt, 2, 1);
    gLay->addWidget(lblDecrypted, 3, 0);
    gLay->addWidget(lnEditDecrypted, 3, 1);
    gLay->addWidget(pshBtnDecrypt, 4, 1);
    setLayout(gLay);

    connect(pshBtnEncrypt, &QPushButton::clicked, this, &Widget::onPshBtnEncryptClicked);
    connect(pshBtnDecrypt, &QPushButton::clicked, this, &Widget::onPshBtnDecryptClicked);
    setFixedSize(600, 200);
}

void Widget::onPshBtnEncryptClicked()
{
    const int blockLen = AES_BLOCK_SIZE;
    unsigned char *pText;
    unsigned char *out;
    unsigned char iv[blockLen] = {
        0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
        0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff
    };
    AES_KEY wctx;

    if (AES_set_encrypt_key(key, 256, &wctx) != 0)
    {
        QMessageBox::critical(this, "Error", "Encryption setkey failed!");
        return;
    }

    int len = (lnEditPlain->text().length() % blockLen == 0) ? lnEditPlain->text().length() : lnEditPlain->text().length() + (blockLen - lnEditPlain->text().length() % blockLen);
    pText = new unsigned char[len];
    memset(pText, '\0', len);
    memcpy(pText, lnEditPlain->text().toLatin1().data(), lnEditPlain->text().length());
    out = new unsigned char[len];

    AES_cbc_encrypt(pText, out, len, &wctx, iv, AES_ENCRYPT);

    lnEditEncrypted->setText(QString(QByteArray((char *)out, len).toHex().toUpper()));

    delete []out;
    delete []pText;
}

void Widget::onPshBtnDecryptClicked()
{
    const int blockLen = AES_BLOCK_SIZE;
    unsigned char *eText;
    unsigned char *out;
    unsigned char iv[blockLen] = {
        0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
        0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff
    };
    AES_KEY wctx;

    if (AES_set_decrypt_key(key, 256, &wctx) != 0)
    {
        QMessageBox::critical(this, "Error", "Encryption setkey failed!");
        return;
    }

    int len = lnEditEncrypted->text().length() / 2;
    eText = new unsigned char[len];
    memcpy(eText, QByteArray::fromHex(lnEditEncrypted->text().toLatin1()), lnEditEncrypted->text().length() / 2);
    out = new unsigned char[len + 1];
    out[len] = '\0';

    AES_cbc_encrypt(eText, out, len, &wctx, iv, AES_DECRYPT);

    lnEditDecrypted->setText(QString((char *)out));

    delete []out;
    delete []eText;
}
