﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>

class Widget : public QWidget
{
    Q_OBJECT
public:
    explicit Widget(QWidget *parent = nullptr);

signals:

private slots:
    void onCmbBoxAlgCurrentIndexChanged(int index);
    void onPshBtnCalcClicked();

private:
    QLabel *lblText;
    QLineEdit *lnEditText;
    QLabel *lblAlg;
    QComboBox *cmbBoxAlg;
    QLabel *lblLength;
    QLabel *lblResult;
    QLineEdit *lnEditResult;
    QPushButton *pshBtnCalc;
};

#endif // WIDGET_H
