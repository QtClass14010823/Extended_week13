﻿#include "Widget.h"

#include <QGridLayout>
#include <openssl/sha.h>
#include <openssl/ripemd.h>

Widget::Widget(QWidget *parent) : QWidget(parent)
{
    lblText = new QLabel("Text:");
    lnEditText = new QLineEdit;
    lblAlg = new QLabel("Algorithm:");
    cmbBoxAlg = new QComboBox;
    cmbBoxAlg->addItem("Sha-256");
    cmbBoxAlg->addItem("Ripmed-160");
    lblLength = new QLabel("");
    lblResult = new QLabel("Digest:");
    lnEditResult = new QLineEdit;
    pshBtnCalc = new QPushButton("Calculate");
    QGridLayout *gLay = new QGridLayout;

    gLay->addWidget(lblText, 0, 0);
    gLay->addWidget(lnEditText, 0, 1);
    gLay->addWidget(lblAlg, 1, 0);
    gLay->addWidget(cmbBoxAlg, 1, 1);
    gLay->addWidget(lblLength, 1, 2);
    gLay->addWidget(lblResult, 2, 0);
    gLay->addWidget(lnEditResult, 2, 1);
    gLay->addWidget(pshBtnCalc, 3, 1);

    setLayout(gLay);
    //connect(cmbBoxAlg, qOverload<int>(&QComboBox::currentIndexChanged), this, &Widget::onCmbBoxAlgCurrentIndexChanged);
    connect(cmbBoxAlg, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this, &Widget::onCmbBoxAlgCurrentIndexChanged);
    connect(pshBtnCalc, &QPushButton::clicked, this, &Widget::onPshBtnCalcClicked);
    onCmbBoxAlgCurrentIndexChanged(0);
    setFixedSize(QSize(500, 200));
}

void Widget::onCmbBoxAlgCurrentIndexChanged(int index)
{
    if (cmbBoxAlg->currentText() == "Sha-256")
        lblLength->setText(QString::number(SHA256_DIGEST_LENGTH));
    else if (cmbBoxAlg->currentText() == "Ripmed-160")
        lblLength->setText(QString::number(RIPEMD160_DIGEST_LENGTH));
}

void Widget::onPshBtnCalcClicked()
{
    QByteArray buffer = lnEditText->text().toLatin1();

    if (cmbBoxAlg->currentText() == "Sha-256")
    {
        unsigned char key[SHA256_DIGEST_LENGTH];
        SHA256_CTX sha256;
        SHA256_Init(&sha256);
        SHA256_Update(&sha256, buffer.data(), buffer.size());
        SHA256_Final(key, &sha256);
        lnEditResult->setText(QString(
                                  QByteArray((char *)key, SHA256_DIGEST_LENGTH).toHex()
                                  ).toUpper());
    }
    else if (cmbBoxAlg->currentText() == "Ripmed-160")
    {
        unsigned char key[SHA256_DIGEST_LENGTH];
        RIPEMD160_CTX ripemd;
        RIPEMD160_Init(&ripemd);
        RIPEMD160_Update(&ripemd, buffer.data(), buffer.size());
        RIPEMD160_Final(key, &ripemd);
        lnEditResult->setText(QString(
                                  QByteArray((char *)key, RIPEMD160_DIGEST_LENGTH).toHex()
                                  ).toUpper());
    }
}
