﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

class Widget : public QWidget
{
    Q_OBJECT
public:
    explicit Widget(QWidget *parent = nullptr);

signals:

private slots:
    void onPshBtnEncryptClicked();
    void onPshBtnDecryptClicked();

private:
    const unsigned char key[32];
    QLabel *lblPlain;
    QLineEdit *lnEditPlain;
    QLabel *lblEncrypted;
    QLineEdit *lnEditEncrypted;
    QLabel *lblDecrypted;
    QLineEdit *lnEditDecrypted;
    QPushButton *pshBtnEncrypt;
    QPushButton *pshBtnDecrypt;
};

#endif // WIDGET_H
