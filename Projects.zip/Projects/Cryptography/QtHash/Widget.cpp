﻿#include "Widget.h"

#include <QGridLayout>
#include <QCryptographicHash>

Widget::Widget(QWidget *parent) : QWidget(parent)
{
    lblText = new QLabel("Text:");
    lnEditText = new QLineEdit;
    lblAlg = new QLabel("Algorithm:");
    cmbBoxAlg = new QComboBox;
    cmbBoxAlg->addItem("Md5", QCryptographicHash::Md5);
    cmbBoxAlg->addItem("Sha1", QCryptographicHash::Sha1);
    lblLength = new QLabel("");
    lblResult = new QLabel("Digest:");
    lnEditResult = new QLineEdit;
    pshBtnCalc = new QPushButton("Calculate");
    QGridLayout *gLay = new QGridLayout;

    gLay->addWidget(lblText, 0, 0);
    gLay->addWidget(lnEditText, 0, 1);
    gLay->addWidget(lblAlg, 1, 0);
    gLay->addWidget(cmbBoxAlg, 1, 1);
    gLay->addWidget(lblLength, 1, 2);
    gLay->addWidget(lblResult, 2, 0);
    gLay->addWidget(lnEditResult, 2, 1);
    gLay->addWidget(pshBtnCalc, 3, 1);

    setLayout(gLay);
    connect(cmbBoxAlg, qOverload<int>(&QComboBox::currentIndexChanged), this, &Widget::onCmbBoxAlgCurrentIndexChanged);
    connect(pshBtnCalc, &QPushButton::clicked, this, &Widget::onPshBtnCalcClicked);
    onCmbBoxAlgCurrentIndexChanged(0);
    setFixedSize(QSize(400, 200));
}

void Widget::onCmbBoxAlgCurrentIndexChanged(int index)
{
    lblLength->setText(QString::number(QCryptographicHash::hashLength((QCryptographicHash::Algorithm)cmbBoxAlg->currentData().toInt())));
}

void Widget::onPshBtnCalcClicked()
{
    QByteArray buffer = lnEditText->text().toLatin1();
    /*QCryptographicHash *crypto;

    switch(cmbBoxAlg->currentData().toInt())
    {
        case QCryptographicHash::Md5:
            crypto = new QCryptographicHash((QCryptographicHash::Algorithm)cmbBoxAlg->currentData().toInt());
            break;
        case QCryptographicHash::Sha1:
            crypto = new QCryptographicHash((QCryptographicHash::Algorithm)cmbBoxAlg->currentData().toInt());
            break;
    }

    crypto->addData(buffer);
    QByteArray result = crypto->result();
    lnEditResult->setText(QString(result.toHex()).toUpper());
    delete crypto;*/

    lnEditResult->setText(QString(
                              QCryptographicHash::hash(buffer, (QCryptographicHash::Algorithm)cmbBoxAlg->currentData().toInt()).toHex()
                              ).toUpper());
}
